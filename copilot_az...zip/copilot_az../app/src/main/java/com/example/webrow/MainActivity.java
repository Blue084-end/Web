package com.example.webrow;

import android.os.Bundle;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
	private WebView webView;
	private EditText urlInput;
	private Button btnGo, btnBack, btnForward, btnRefresh;
	private boolean cookiesEnabled = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Ánh xạ các thành phần UI
		webView = findViewById(R.id.webview);
		urlInput = findViewById(R.id.url_input);
		btnGo = findViewById(R.id.btn_go);
		btnBack = findViewById(R.id.btn_back);
		btnForward = findViewById(R.id.btn_forward);
		btnRefresh = findViewById(R.id.btn_refresh);

		// Cấu hình WebView
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				Toast.makeText(MainActivity.this, "Lỗi tải trang: " + description, Toast.LENGTH_SHORT).show();
			}
		});

		WebSettings webSettings = webView.getSettings();
		webSettings.setJavaScriptEnabled(true);

		// Bật cookie hiện đại
		CookieManager cookieManager = CookieManager.getInstance();
		cookieManager.setAcceptCookie(cookiesEnabled);
		cookieManager.setAcceptThirdPartyCookies(webView, cookiesEnabled);

		// Load trang mặc định
		webView.loadUrl("https://duckduckgo.com");

		// Xử lý nút "Go"
		btnGo.setOnClickListener(v -> {
			String url = urlInput.getText().toString().trim();
			if (!url.startsWith("http://") && !url.startsWith("https://")) {
				url = "https://" + url;
			}
			if (Patterns.WEB_URL.matcher(url).matches()) {
				webView.loadUrl(url);
			} else {
				Toast.makeText(this, "Địa chỉ không hợp lệ", Toast.LENGTH_SHORT).show();
			}
		});

		// Nút Back
		btnBack.setOnClickListener(v -> {
			if (webView.canGoBack()) {
				webView.goBack();
			} else {
				Toast.makeText(this, "Không có trang trước", Toast.LENGTH_SHORT).show();
			}
		});

		// Nút Forward
		btnForward.setOnClickListener(v -> {
			if (webView.canGoForward()) {
				webView.goForward();
			} else {
				Toast.makeText(this, "Không có trang tiếp theo", Toast.LENGTH_SHORT).show();
			}
		});

		// Nút Refresh
		btnRefresh.setOnClickListener(v -> webView.reload());
	}

	// Xử lý nút Back vật lý
	@Override
	public void onBackPressed() {
		if (webView.canGoBack()) {
			webView.goBack();
		} else {
			super.onBackPressed();
		}
	}

	// Tạo menu tùy chọn
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.web_menu, menu);
		return true;
	}

	// Xử lý khi chọn item trong menu
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.toggle_cookie) {
			cookiesEnabled = !cookiesEnabled;
			CookieManager.getInstance().setAcceptCookie(cookiesEnabled);
			CookieManager.getInstance().setAcceptThirdPartyCookies(webView, cookiesEnabled);
			String msg = cookiesEnabled ? "Đã bật cookie" : "Đã tắt cookie";
			Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
